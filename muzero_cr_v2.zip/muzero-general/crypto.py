import copy

import pandas as pd
import numpy as np
import random
from collections import deque
from utils import Write_to_file, TradingGraph

import math
import gym
from gym import spaces, logger
from gym.utils import seeding


class CryptoBot(gym.Env):
    def __init__(self):
        # Определить пространство действия и размер состояния и другие настраиваемые параметры
        df = pd.read_csv('./BTC-USD.csv')
        df = df.sort_values('Date')

        self.lookback_window_size = 50
        self.initial_balance=1000
        self.lookback_window_size=50
        self.Render_range = 100
        #self.env_steps_size = 0
        self.df = df.dropna().reset_index()
        self.df_total_steps = len(self.df) - 1

        self.rewards = deque(maxlen=self.Render_range)
        self.punish_value = 0
        self.prev_episode_orders = 0
        self.env_steps_size = 0

        # Action space from 0 to 3, 0 is hold, 1 is buy, 2 is sell
        self.action_space = np.array([0, 1, 2])

        # История ордеров содержит значения balance, net_worth, crypto_bought, crypto_sold, crypto_hold для последних шагов lookback_window_size.
        self.orders_history = deque(maxlen=self.lookback_window_size)

        # История рынка содержит значения OHLC для цен размера последнего окна ретроспективного анализа.
        self.market_history = deque(maxlen=self.lookback_window_size)

        # State size содержит историю Market+Orders для последних шагов lookback_window_size
        self.state_size = (self.lookback_window_size, 10)

    # create tensorboard writer
    #def create_writer(self):
     #   self.replay_count = 0
     #   self.writer = SummaryWriter(comment="Crypto_trader")
    # Reset the state of the environment to an initial state
    def reset(self):
        self.visualization = TradingGraph(Render_range=self.Render_range)  # init visualization
        self.trades = deque(maxlen=self.Render_range)  # limited orders memory for visualization

        self.balance = self.initial_balance
        self.net_worth = self.initial_balance
        self.prev_net_worth = self.initial_balance
        self.crypto_held = 0
        self.crypto_sold = 0
        self.crypto_bought = 0
        self.episode_orders = 0  # test
        env_steps_size=0
        self.rewards = deque(maxlen=self.Render_range)
        self.punish_value = 0
        self.prev_episode_orders = 0
        self.env_steps_size = env_steps_size
        if env_steps_size > 0:  # used for training dataset
            self.start_step = random.randint(self.lookback_window_size, self.df_total_steps - env_steps_size)
            self.end_step = self.start_step + env_steps_size
        else:  # used for testing dataset
            self.start_step = self.lookback_window_size
            self.end_step = self.df_total_steps

        self.current_step = self.start_step

        for i in reversed(range(self.lookback_window_size)):
            current_step = self.current_step - i
            self.orders_history.append(
                [self.balance, self.net_worth, self.crypto_bought, self.crypto_sold, self.crypto_held])
            self.market_history.append([self.df.loc[current_step, 'Open'],
                                        self.df.loc[current_step, 'High'],
                                        self.df.loc[current_step, 'Low'],
                                        self.df.loc[current_step, 'Close'],
                                        self.df.loc[current_step, 'Volume']
                                        ])

        state = np.concatenate((self.market_history, self.orders_history), axis=1)
        return state

    # Execute one time step within the environment
    def step(self, action):
        self.crypto_bought = 0
        self.crypto_sold = 0
        self.current_step += 1

        # Set the current price to a random price between open and close
        current_price = float(0.0 if self.df.loc[self.current_step, 'Open'] is None else self.df.loc[self.current_step, 'Open'])
        #current_price = random.uniform(
        #    float(self.df.loc[self.current_step, 'Open']),
        #    float(self.df.loc[self.current_step, 'Close']))

        Date = self.df.loc[self.current_step, 'Date']  # for visualization
        #High = self.df.loc[self.current_step, 'High']  # for visualization
        #Low = self.df.loc[self.current_step, 'Low']  # for visualization
        #Date = float(0.0 if self.df.loc[self.current_step, 'Date']  is None else self.df.loc[self.current_step, 'Date'])
        High = float(0.0 if self.df.loc[self.current_step, 'High']  is None else self.df.loc[self.current_step, 'High'])
        Low =  float(0.0 if self.df.loc[self.current_step, 'Low']   is None else self.df.loc[self.current_step, 'Low'])

        if action == 0:  # Hold
            pass

        elif action == 1 and self.balance > 0:
            # Buy with 100% of current balance
            self.crypto_bought = self.balance / current_price
            self.balance -= self.crypto_bought * current_price
            self.crypto_held += self.crypto_bought
            self.trades.append({'Date': Date, 'High': High, 'Low': Low, 'total': self.crypto_bought, 'type': "buy",
                                'current_price': current_price})
            #self.trades.append({'Date': Date, 'High': High, 'Low': Low, 'total': self.crypto_bought, 'type': "buy"})
            self.episode_orders += 1

        elif action == 2 and self.crypto_held > 0:
            # Sell 100% of current crypto held
            self.crypto_sold = self.crypto_held
            self.balance += self.crypto_sold * current_price
            self.crypto_held -= self.crypto_sold
            self.trades.append({'Date' : Date, 'High' : High, 'Low' : Low, 'total': self.crypto_sold, 'type': "sell", 'current_price': current_price})
            #self.trades.append({'Date': Date, 'High': High, 'Low': Low, 'total': self.crypto_sold, 'type': "sell"})
            self.episode_orders += 1

        self.prev_net_worth = self.net_worth
        self.net_worth = self.balance + self.crypto_held * current_price

        self.orders_history.append(
            [self.balance, self.net_worth, self.crypto_bought, self.crypto_sold, self.crypto_held])
        #Write_to_file(Date, self.orders_history[-1])

        # Calculate reward
        #reward = self.net_worth - self.prev_net_worth
        reward = self.get_reward()
        #reward_w = self.get_reward()
        #reward = float(0.0 if reward_w is None else reward_w)

        if self.net_worth <= self.initial_balance / 2:
            done = True
        else:
            done = False

        obs = self._next_observation()

        return obs, reward, done, {}

    # Get the data points for the given current_step
    def _next_observation(self):
        self.market_history.append([self.df.loc[self.current_step, 'Open'],
                                    self.df.loc[self.current_step, 'High'],
                                    self.df.loc[self.current_step, 'Low'],
                                    self.df.loc[self.current_step, 'Close'],
                                    self.df.loc[self.current_step, 'Volume']
                                    ])
        obs = np.concatenate((self.market_history, self.orders_history), axis=1)
        return obs


    # Calculate reward
    def get_reward(self):
        self.punish_value += self.net_worth * 0.00001
        if self.episode_orders > 1 and self.episode_orders > self.prev_episode_orders:
            self.prev_episode_orders = self.episode_orders
            if self.trades[-1]['type'] == "buy" and self.trades[-2]['type'] == "sell":
                reward = float(0.0 if self.trades[-2]['total'] is None else self.trades[-2]['total'])*float(0.0 if self.trades[-2]['current_price'] is None else self.trades[-2]['current_price']) - float(0.0 if self.trades[-2]['total'] is None else self.trades[-2]['total'])*float(0.0 if self.trades[-1]['current_price'] is None else self.trades[-1]['current_price'])
                reward -= self.punish_value
                self.punish_value = 0   
                self.trades[-1]["Reward"] = reward
                return reward
            elif self.trades[-1]['type'] == "sell" and self.trades[-2]['type'] == "buy":
                reward = float(0.0 if self.trades[-1]['total'] is None else  self.trades[-1]['total'])*float(0.0 if self.trades[-1]['current_price'] is None else self.trades[-1]['current_price']) - float(0.0 if self.trades[-2]['total'] is None else self.trades[-2]['total'])*float(0.0 if self.trades[-2]['current_price'] is None else self.trades[-2]['current_price'])
                reward -= self.punish_value
                self.punish_value = 0
                self.trades[-1]["Reward"] = reward
                return reward
        else:
            return 0 - self.punish_value


    # render environment
    def render(self, visualize=False):
        # print(f'Step: {self.current_step}, Net Worth: {self.net_worth}')
        if visualize:
            Date = self.df.loc[self.current_step, 'Date']
            Open = float(self.df.loc[self.current_step, 'Open'])
            Close = float(self.df.loc[self.current_step, 'Close'])
            High = float(self.df.loc[self.current_step, 'High'])
            Low = float(self.df.loc[self.current_step, 'Low'])
            Volume = float(self.df.loc[self.current_step, 'Volume'])

            # Render the environment to the screen
            self.visualization.render(Date, Open, High, Low, Close, Volume, self.net_worth, self.trades)