#ifndef SAMPLES_H
#define SAMPLES_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>

using namespace std;

//
std::vector<std::vector<int> > gen_samples(int N, int C, int n);

#endif
