class TestCFR:
    def test_cfr(self):
        pass
