

import torch

p = torch.cuda.current_device()

s = torch.cuda.device(0)

c = torch.cuda.device_count()

n = torch.cuda.get_device_name(0)

t = torch.cuda.is_available()
print(p)
print(s)
print(c)
print(n)
print(t)

