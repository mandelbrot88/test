import pre_env




name = "Svetoch"

if __name__ == '__main__':
    pre_env.print_hi(name)


